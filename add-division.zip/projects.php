<?php include 'common/header.php'; ?>
<style>
  .input-group {
    margin-bottom: 1rem !important;
  }
  .form-control {
    height: 38px;
  }
  .alert-danger {
    margin-top: 10px;
    padding: 10px;
    border-radius: 4px;
  }
  /* Custom styling for DataTables */
  .dataTables_filter {
      text-align: right;
      float: right;
      display: flex;
      align-items: center;
      justify-content: flex-end;
  }
  
  .dataTables_length {
      padding-top: 0.5rem;
      float: left;
  }
  
  .dataTables_filter input {
      margin-left: 0.5rem;
      display: inline-block;
      width: auto;
  }
  
  /* Clear floats */
  .dataTables_wrapper .row:after {
      content: "";
      display: table;
      clear: both;
  }
  .badge {
      font-size: 85%;
      padding: 0.4em 0.7em;
  }
  .badge-planned {
      background-color: #6c757d;
      color: white;
  }
  .badge-in-progress {
      background-color: #007bff;
      color: white;
  }
  .badge-active {
      background-color: #28a745;
      color: white;
  }
  .badge-pending {
      background-color: #ffc107;
      color: #212529;
  }
  .btn-group {
      white-space: nowrap;
  }
</style>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="card-title">Project List</h3>
                <div class="card-tools">
                    <a href="add-project.php" class="btn btn-primary">Add Project</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <table id="projectTable" class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Project Name</th>
                        <th>Job No</th>
                        <th>Client Name</th>
                        <th>Project Duration</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Data will be loaded dynamically by DataTables -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete project "<span id="projectNameToDelete"></span>"?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">Delete</button>
            </div>
        </div>
    </div>
</div>

<!-- Font Awesome -->
<link rel="stylesheet" href="css/all.min.css">
<!-- DataTables CSS -->
<link rel="stylesheet" href="css/dataTables.bootstrap4.min.css">

<!-- DataTables JS -->
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap4.min.js"></script>

<script>
$(document).ready(function() {
    // Initialize DataTable
    var table = $('#projectTable').DataTable({
        "processing": true,
        "serverSide": true,
        "pageLength": 10,
        "lengthChange": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "responsive": true,
        "pagingType": "full_numbers",
        "dom": '<"row mb-3"<"col-md-6"l><"col-md-6"f>>rt<"row"<"col-md-6"i><"col-md-6"p>>',
        "displayStart": <?php echo (isset($_GET['page']) ? ((int)$_GET['page'] - 1) * (isset($_GET['limit']) ? (int)$_GET['limit'] : 10) : 0); ?>,
        "pageLength": <?php echo isset($_GET['limit']) ? (int)$_GET['limit'] : 10; ?>,
        "drawCallback": function(settings) {
            // Update URL with current page information without reloading
            var api = this.api();
            var pageInfo = api.page.info();
            var pageNum = pageInfo.page + 1;
            var currentUrl = new URL(window.location.href);
            currentUrl.searchParams.set('page', pageNum);
            currentUrl.searchParams.set('limit', pageInfo.length);
            window.history.replaceState({}, '', currentUrl.toString());
            
            console.log('Draw callback - Page info:', pageInfo);
            console.log('Total records:', pageInfo.recordsTotal);
            console.log('Records per page:', pageInfo.length);
            console.log('Current page:', pageInfo.page);
        },
        "language": {
            "emptyTable": "No projects available",
            "info": "Showing _START_ to _END_ of _TOTAL_ entries",
            "infoEmpty": "Showing 0 to 0 of 0 entries",
            "infoFiltered": "",
            "lengthMenu": "Show _MENU_ entries",
            "loadingRecords": "Loading...",
            "processing": "Processing...",
            "search": "Search:",
            "zeroRecords": "No matching records found",
            "paginate": {
                "first": "First",
                "last": "Last",
                "next": "Next",
                "previous": "Previous"
            }
        },
        "order": [[0, "asc"]],
        "ajax": {
            url: '<?php echo API_URL; ?>project-listing',
            "type": "POST",
            "contentType": "application/json",
            "data": function(d) {
                // Calculate page number ensuring it's at least 1
                var calculatedPage = Math.floor(d.start / d.length) + 1;
                var pageNumber = Math.max(1, calculatedPage); // Ensure page is never less than 1
                
                var params = {
                    access_token: "<?php echo $_SESSION['access_token']; ?>",
                    limit: d.length,
                    page: pageNumber,
                    search: d.search.value
                };
                
                // Debug information
                console.log('Start:', d.start, 'Length:', d.length, 'Calculated page:', calculatedPage, 'Final page:', pageNumber);
                
                console.log('DataTables Request:', params);
                
                return JSON.stringify(params);
            },
            "dataSrc": function(json) {
                // Update total record count for pagination
                if (json.data && json.data.projects) {
                    return json.data.projects;
                }
                return [];
            },
            "dataFilter": function(data) {
                var json = JSON.parse(data);
                console.log('API Response:', json); // Log the API response for debugging
                
                // Check if the API call was successful
                if (json.is_successful === "1") {
                    // Make sure the response has the required DataTables properties
                    if (json.data && typeof json.data.total_count !== 'undefined') {
                        json.recordsTotal = parseInt(json.data.total_count) || 0;
                        json.recordsFiltered = parseInt(json.data.total_count) || 0;
                        
                        // Ensure we have at least as many records as we have items in the current page
                        if (json.data.projects && json.data.projects.length > 0 && json.recordsTotal < json.data.projects.length) {
                            json.recordsTotal = json.data.projects.length;
                            json.recordsFiltered = json.data.projects.length;
                        }
                    } else {
                        // Fallback values if the API doesn't return total_count
                        json.recordsTotal = (json.data && json.data.projects) ? json.data.projects.length * 3 : 0; // Multiply by estimated page count
                        json.recordsFiltered = json.recordsTotal;
                    }
                } else {
                    // Handle API error
                    console.error('API Error:', json.errors);
                    // Set empty data and show error message
                    json.data = { projects: [] };
                    json.recordsTotal = 0;
                    json.recordsFiltered = 0;
                    
                    // Show error toast
                    setTimeout(function() {
                        var errorMsg = '';
                        if (json.errors) {
                            for (var key in json.errors) {
                                errorMsg += key + ': ' + json.errors[key].join(', ') + '<br>';
                            }
                        } else {
                            errorMsg = 'Error loading data from server.';
                        }
                        
                        $(document).Toasts('create', {
                            class: 'bg-danger',
                            title: 'Error',
                            body: errorMsg,
                            autohide: true,
                            delay: 5000
                        });
                    }, 500);
                }
                
                console.log('Modified Response:', json); // Log the modified response
                return JSON.stringify(json);
            }
        },
        "columns": [
            { "data": "project_name" },
            { "data": "job_no" },
            { "data": "client_name" },
            { 
                "data": "project_duration",
                "render": function(data, type, row) {
                    return data || '-';
                }
            },
            { "data": "location" },
            { 
                "data": "status",
                "render": function(data) {
                    var status = data ? data.toLowerCase() : '';
                    var statusClass = '';
                    var statusText = data || 'Pending';
                    
                    switch(status) {
                        case 'active':
                            statusClass = 'badge-active';
                            break;
                        case 'in progress':
                        case 'in-progress':
                            statusClass = 'badge-in-progress';
                            statusText = 'In Progress';
                            break;
                        case 'planned':
                            statusClass = 'badge-planned';
                            break;
                        case 'pending':
                        default:
                            statusClass = 'badge-pending';
                            statusText = 'Pending';
                    }
                    
                    return '<span class="badge ' + statusClass + '">' + statusText + '</span>';
                }
            },
            {
                "data": "project_id",
                "render": function(data, type, row) {
                    return '<div class="btn-group">' +
                           '<a href="view-project.php?id=' + data + '" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i> View</a> ' +
                           '<a href="edit-project.php?id=' + data + '" class="btn btn-info btn-sm"><i class="fas fa-edit"></i> Edit</a>' +
                           '</div>';
                }
            }
        ]
    });

    // Make sure pagination is working correctly
    $(document).on('click', '.paginate_button', function(e) {
        console.log('Pagination button clicked');
    });
    
    // Initialize with the current page if it exists in the URL
    var urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('page')) {
        var pageNum = parseInt(urlParams.get('page')) - 1; // DataTables uses 0-based index
        if (pageNum >= 0) {
            setTimeout(function() {
                table.page(pageNum).draw('page');
                console.log('Set page to:', pageNum);
            }, 100);
        }
    }
    
    // Listen for page changes
    table.on('page.dt', function() {
        var info = table.page.info();
        console.log('Page changed to:', info.page);
        
        // Force a redraw to ensure the server gets the correct page request
        setTimeout(function() {
            table.ajax.reload(null, false); // null callback, false to keep current page
        }, 0);
    });

    var projectIdToDelete = null;
    var projectNameToDelete = null;

    // Handle delete button click using event delegation
    $('#projectTable').on('click', '.delete-project', function() {
        projectIdToDelete = $(this).data('project-id');
        projectNameToDelete = $(this).data('project-name');
        $('#projectNameToDelete').text(projectNameToDelete);
        $('#deleteModal').modal('show');
    });

    // Handle confirm delete
    $('#confirmDelete').click(function() {
        if (!projectIdToDelete) return;
        
        $.ajax({
            url: '<?php echo API_URL; ?>delete-project',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                access_token: "<?php echo $_SESSION['access_token']; ?>",
                project_id: projectIdToDelete
            }),
            success: function(response) {
                if (response.is_successful === "1") {
                    // Reload the DataTable
                    table.ajax.reload();
                    
                    // Show success message
                    $(document).Toasts('create', {
                        class: 'bg-success',
                        title: 'Success',
                        body: 'Project deleted successfully',
                        autohide: true,
                        delay: 3000
                    });
                } else {
                    // Show error message
                    $(document).Toasts('create', {
                        class: 'bg-danger',
                        title: 'Error',
                        body: response.errors ? Object.values(response.errors).join('<br>') : 'Error deleting project',
                        autohide: true,
                        delay: 3000
                    });
                }
            },
            error: function() {
                // Show error message
                $(document).Toasts('create', {
                    class: 'bg-danger',
                    title: 'Error',
                    body: 'Error deleting project. Please try again.',
                    autohide: true,
                    delay: 3000
                });
            },
            complete: function() {
                $('#deleteModal').modal('hide');
                projectIdToDelete = null;
                projectNameToDelete = null;
            }
        });
    });

    // Add active class to navigation
    $('#projects-menu').addClass('active');
});
</script>

<?php include 'common/footer.php'; ?>
