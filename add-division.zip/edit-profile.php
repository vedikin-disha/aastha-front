<?php include 'common/header.php'; ?>
<style>
  .input-group {
    margin-bottom: 1rem !important;
  }
  .form-control {
    height: 38px;
  }
  .alert-danger {
    margin-top: 10px;
    padding: 10px;
    border-radius: 4px;
  }
</style>

<div class="card card-primary">
  <div class="card-header">
    <h3 class="card-title">Edit Profile</h3>
  </div>
  <div class="card-body">
    <!-- data table data -->
  </div>
</div>

<!-- Font Awesome -->
<link rel="stylesheet" href="css/all.min.css">


<script>
  // add nav-link active class to id = circle
  $('#profile a').addClass('active');
  $('#profile a').addClass('nav-link');
</script>

<?php include 'common/footer.php'; ?>

