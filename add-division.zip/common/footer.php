<script src="js/common.js"></script>

</div>
</div>
</div>

<!-- Footer -->
<footer class="main-footer text-sm">

  <strong>&copy; 2025 <a href="#">Aastha Techno</a>.</strong> All rights reserved.
  | 
  <span>Design & Developed by <a href="https://www.vedikin.com">VedikIn Solutions</a></span>

</footer>
</div>

<!-- Scripts -->
<!-- <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script> -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script> -->

<!-- Optional JS Plugins (if needed)
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/plugins/chart.js/Chart.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/plugins/summernote/summernote-bs4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/plugins/daterangepicker/daterangepicker.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/plugins/moment/moment.min.js"></script> -->

<!-- AdminLTE App JS -->
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>

</body>
</html>